package app.waste2wealth.com.login.onboarding

data class ObData(
    val image: Int,
    val title: String,
    val description: String
)
